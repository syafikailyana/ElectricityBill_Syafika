package com.example.application;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ListActivity;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText editTextUnit, editTextRebate;
    Spinner spinnerMonth;
    Button buttonCalculate, buttonView, buttonAbout;
    DataHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DataHelper(this);

        editTextUnit = findViewById(R.id.editTextUnit);
        editTextRebate = findViewById(R.id.editTextRebate);
        spinnerMonth = findViewById(R.id.spinnerMonth);
        buttonCalculate = findViewById(R.id.buttonCalculate);
        buttonView = findViewById(R.id.buttonView);
        buttonAbout = findViewById(R.id.buttonAbout);

        buttonCalculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                calculateAndStore();
            }
        });

        buttonView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, ListActivity.class);
                startActivity(intent);
            }
        });

        buttonAbout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, AboutActivity.class);
                startActivity(intent);
            }
        });
    }

    private void calculateAndStore() {
        String month = spinnerMonth.getSelectedItem().toString();
        String unitStr = editTextUnit.getText().toString();
        String rebateStr = editTextRebate.getText().toString();

        if (unitStr.isEmpty() || rebateStr.isEmpty()) {
            Toast.makeText(getApplicationContext(), "Please enter all input fields", Toast.LENGTH_SHORT).show();
            return;
        }

        int units = Integer.parseInt(unitStr);
        double rebate = Double.parseDouble(rebateStr);

        double totalCharges = calculateCharges(units);
        double finalCost = totalCharges - (totalCharges * rebate / 100.0);

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.execSQL("INSERT INTO bill(month, unit, rebate, charges, final) VALUES('" +
                month + "', '" + units + "', '" + rebate + "', '" + totalCharges + "', '" + finalCost + "')");

        Toast.makeText(getApplicationContext(), "Data saved", Toast.LENGTH_SHORT).show();
    }

    private double calculateCharges(int unit) {
        double total = 0;

        if (unit <= 200) {
            total = unit * 0.218;
        } else if (unit <= 300) {
            total = (200 * 0.218) + ((unit - 200) * 0.334);
        } else if (unit <= 600) {
            total = (200 * 0.218) + (100 * 0.334) + ((unit - 300) * 0.516);
        } else {
            total = (200 * 0.218) + (100 * 0.334) + (300 * 0.516) + ((unit - 600) * 0.546);
        }

        return total;
    }
}
